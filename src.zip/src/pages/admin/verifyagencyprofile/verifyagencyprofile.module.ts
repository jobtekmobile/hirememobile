import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerifyagencyprofilePage } from './verifyagencyprofile';

@NgModule({
  declarations: [
    VerifyagencyprofilePage,
  ],
  imports: [
    IonicPageModule.forChild(VerifyagencyprofilePage),
  ],
})
export class VerifyagencyprofilePageModule {}
