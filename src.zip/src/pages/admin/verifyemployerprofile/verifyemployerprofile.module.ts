import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerifyemployerprofilePage } from './verifyemployerprofile';

@NgModule({
  declarations: [
    VerifyemployerprofilePage,
  ],
  imports: [
    IonicPageModule.forChild(VerifyemployerprofilePage),
  ],
})
export class VerifyemployerprofilePageModule {}
