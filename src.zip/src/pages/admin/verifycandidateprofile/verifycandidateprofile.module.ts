import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerifycandidateprofilePage } from './verifycandidateprofile';

@NgModule({
  declarations: [
    VerifycandidateprofilePage,
  ],
  imports: [
    IonicPageModule.forChild(VerifycandidateprofilePage),
  ],
})
export class VerifycandidateprofilePageModule {}
