import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerifyjobofferprofilePage } from './verifyjobofferprofile';

@NgModule({
  declarations: [
    VerifyjobofferprofilePage,
  ],
  imports: [
    IonicPageModule.forChild(VerifyjobofferprofilePage),
  ],
})
export class VerifyjobofferprofilePageModule {}
