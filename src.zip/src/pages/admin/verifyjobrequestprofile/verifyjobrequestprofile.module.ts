import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerifyjobrequestprofilePage } from './verifyjobrequestprofile';

@NgModule({
  declarations: [
    VerifyjobrequestprofilePage,
  ],
  imports: [
    IonicPageModule.forChild(VerifyjobrequestprofilePage),
  ],
})
export class VerifyjobrequestprofilePageModule {}
