import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SearchjobsPage } from './serchjobs';

@NgModule({
  declarations: [
    SearchjobsPage,
  ],
  imports: [
    IonicPageModule.forChild(SearchjobsPage),
  ],
})
export class SerchjobsPageModule {}
