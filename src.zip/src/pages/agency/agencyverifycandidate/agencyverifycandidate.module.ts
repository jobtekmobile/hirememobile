import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AgencyverifycandidatePage } from './agencyverifycandidate';

@NgModule({
  declarations: [
    AgencyverifycandidatePage,
  ],
  imports: [
    IonicPageModule.forChild(AgencyverifycandidatePage),
  ],
})
export class AgencyverifycandidatePageModule {}
