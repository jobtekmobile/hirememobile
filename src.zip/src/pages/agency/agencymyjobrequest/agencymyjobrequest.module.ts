import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AgencymyjobrequestPage } from './agencymyjobrequest';

@NgModule({
  declarations: [
    AgencymyjobrequestPage,
  ],
  imports: [
    IonicPageModule.forChild(AgencymyjobrequestPage),
  ],
})
export class AgencymyjobrequestPageModule {}
