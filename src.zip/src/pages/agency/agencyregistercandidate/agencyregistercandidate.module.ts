import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AgencyregistercandidatePage } from './agencyregistercandidate';

@NgModule({
  declarations: [
    AgencyregistercandidatePage,
  ],
  imports: [
    IonicPageModule.forChild(AgencyregistercandidatePage),
  ],
})
export class AgencyregistercandidatePageModule {}
